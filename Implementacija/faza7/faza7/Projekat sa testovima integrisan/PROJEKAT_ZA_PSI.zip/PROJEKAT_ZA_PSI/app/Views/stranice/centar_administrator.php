<?php
// Teodora Peric 0283/18 postavljanje centra za pocetnu stranicu administratora koji je dizajnirao Pavle Stefanovic 0562/18
?>

        <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
              <div class="sredina">
                <h2 class="dobrodosliTekst">Dobrodošli u GroomRoom administratore!</h2>
                
                <hr class="linija">
              </div>
            </div>
            <div class="col-sm-1 " >
             
            </div>
         
        </div>

