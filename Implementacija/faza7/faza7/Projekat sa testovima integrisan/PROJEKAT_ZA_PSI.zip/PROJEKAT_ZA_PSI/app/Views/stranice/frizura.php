<?php

?>
     <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
                 <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst">FRIZURA </h2>
                <img class="usluga_slika2" src="/images/frizura.png">
                <p class="flavor_text" style="text-align: left;">
                  Odelo ne čini čoveka, ali da li frizura čini psa? Šalimo se, samo nam je preslatko kada pogledamo fotografije pasa pre posete frizerskom salonu i posle posete. Sada i vaš pas može izgledati kao veliki frajer Džejms Din.
                  <br><br>
                  Vaš pas može imati potpuno modernu frizuru, garantujemo šišanje po poslednjoj modi. Savršeno je kakve sve frizure mogu da dobiju.
                  <br><br>
                  Naši saloni mogu srediti vašeg psa po želji!    
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
         
        </div>