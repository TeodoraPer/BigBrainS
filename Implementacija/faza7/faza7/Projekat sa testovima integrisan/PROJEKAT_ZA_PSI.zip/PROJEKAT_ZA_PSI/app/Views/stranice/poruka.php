<?php

/* Pavle Stefanovic 0562/18
 */?>


<a href="https://api.whatsapp.com/send?phone=0612926411" target="_blank"><i class="fa fa-whatsapp" style="font-size:36px"></i></a>
<a href="mailto:groomroom@email.com"><i class="fa fa-envelope" style="font-size:36px" target="_blank"></i></a>
<a href="https://globfone.com/call-phone/" target="_blank">
    <i class="fa fa-phone" style="font-size:36px"></i></a>

<br><br>