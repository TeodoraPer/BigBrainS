<?php
?>
   <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
                 <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst">ČIŠĆENJE OČIJU</h2>
                <img class="usluga_slika2" src="/images/oci.png">
                <p class="flavor_text" style="text-align: left;">Oči su veoma delikatan organ, ali iznenađujuće izdržljive. Postoje koraci koje možete preduzeti da biste se brinuli o očima vašeg kućnog ljubimca, tako da one kasnije nisu podložne infekcijama i traumama. Naučite kako da čistite oči Vašem psu.
                <br>
                <br>
                Veoma je važno da posmatrate oči Vašeg kućnog ljubimca, tako da možete na vreme da uočite bilo kakav problem i sprečite ga.
                <br>
                <br>
                Neki psi, kao što su Pudle, Kokeri i mali Terijeri, nemaju odgovarajući mehanizam za isušivanje suza iz suzne žlezde (suzavac). Prekomerne suze cure niz donji kapak, što uzrokuje ružno prebojavanje.
                <br>
                <br>
                Na našoj platformi možete pronaći salone koji će se pobrinuti da Vašem ljubimcu oči budu čiste, i uredne!
                Pored toga što će vaš ljubimac lepše izgledati, ovaj proces pomaže u sprečavanju iritacija i infekcija!
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
           
        </div>
