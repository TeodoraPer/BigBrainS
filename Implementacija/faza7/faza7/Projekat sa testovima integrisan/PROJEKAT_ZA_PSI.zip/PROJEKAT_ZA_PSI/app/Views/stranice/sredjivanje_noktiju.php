<?php

?>
  <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" > <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst"> SREĐIVANJE NOKTIJU </h2>
                <img class="usluga_slika2" src="/images/nokti.png">
                <p class="flavor_text" style="text-align: left;">
                Jedan od važnih aspekata psećeg zdravlja je - skraćivanje noktiju!
                <br><br>
                Najbolje je ako se s time počne vrlo rano - u biti, šteneći noktići se mogu skratiti čim počnu biti oštri, nekada još i dok sisaju, kako bi se izbeglo grebanje dojki njihove mame. Naravno, ko je imao štence i djecu - zna da to ne ide lako niti odmah možete odrezati sve nokte jedne šape/ruke - a kamoli više od toga.
                Kod štenaca koji su sasvim mali najlakše je to učiniti dok su pospani, a kod onih od 2 meseca i više - pravilo je “jedan noktić, jedan keksić”.
                <br><br>
                Pošto nokti kod pasa, kao i kod ljudi, rastu neprestano, kod neaktivnih pasa mogu postati predugi. Takvi nokti mogu da izazovu bol kod životinje, da mu smetaju pri kretanju ili da se povrede i inficiraju. U tim slučajevima ne bi bilo loše da svom ljubimcu skratite nokte.
                <br><br>
                Kod delikatnih stvari kao što je skraćivanje noktiju, gde psi često ne vole ili odbijaju takve procedure, dobro je prepustiti to profesionalcima.
                Zakažite tretman u jednom od naših profesionalnih salona danas!
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
          
        </div>