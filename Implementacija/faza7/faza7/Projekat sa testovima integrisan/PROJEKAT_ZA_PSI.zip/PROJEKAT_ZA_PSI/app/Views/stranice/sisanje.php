<?php
?>
 <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" > <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst"> 
                     ŠIŠANJE </h2>
                <img class="usluga_slika2" src="/images/sisanje.png">
                <p class="flavor_text" style="text-align: left;">
                Šišanje pasa spada u deo osnovne higijene i održavanja dlake. Šišanje pasa je važno, jer se tako uklanja i mrtva dlaka iz krzna, a rezultat šišanja su uredni i čisti kućni ljubimci. Dlaka na leđima je deo tela koji nije naročito osetljiv, pa će većina pasa dozvoliti češljanje i održavanje dlake. Međutim, dlaka ispod pazuha, na stomaku i između jastučića na šapama često stvara probleme i vlasniku i psu. Redovno sređivanje šapa svakako je preventiva potencijalnih problema, kojima su skloni kućni ljubimci.
                <br><br>
                Dlake psa ne rastu kontinuirano, nego u vremenskim intervalima. Jedno kraće vreme dlaka raste, zatim nastaje period mirovanja i na kraju odumiranja. Svakodnevno četkanje i redovno šišanje pasa pomoći će u skidanju nečistoća sa dlake i kože i činiće da vaši kućni ljubimci imaju sjajno, uredno i kvalitetno krzno.
                <br><br>
                Izaberite jedan od naših salona, i dajte nam da se pobrinemo za Vašeg ljubimca!
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
           
        </div>