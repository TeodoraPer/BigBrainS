<?php
?>

        <div class="row divCentar">
            <div class="col-sm-1 " >
            </div>
  <div class="col-sm-10 centar" >
              <div class="sredina">
                <h2 class="uslugeTekst"> USLUGE </h2>
                <div class="row divUsluga">
                  
                  <div class="col-sm-4" style="margin-left:-20px" >
                      <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px; width:350px; ">                       
                        <img class="car-img-top" src="/images/sisanje.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  > <?php   echo anchor("$controller/sisanje", "Šišanje",'class="button4"'); ?></span>
                          
                            </div> 
                        <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px ; width:350px">
                       
                        <img class="car-img-top" src="/images/kupanje.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  >  <?php   echo anchor("$controller/kupanje", "Kupanje",'class="button4"'); ?></span>
                          
                       </div> 
                       <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px ; width:350px">
                       
                        <img class="car-img-top" src="/images/cesljanje.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  >  <?php   echo anchor("$controller/cesljanje", "Češljanje",'class="button4"'); ?></span>
                       </div> 
                 
                  </div>
                <div class="col-sm-4"  style="margin-left:-40px">
                        <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px; width:405px">
                       
                        <img class="car-img-top" src="/images/usi.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  ><?php   echo anchor("$controller/ciscenje_usiju", "  Čišćenje ušiju",'class="button4"'); ?></span>
                          
                            </div> 
                        <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px ; width:350px">
                       
                        <img class="car-img-top" src="/images/frizura.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  >           <?php   echo anchor("$controller/frizura", "Frizura",'class="button4"'); ?></span>
                          
                      
                       </div> 
                      
                           <div class="usluga" style="background-color: #FFC7C7; border-radius: 10px; width:430px">
                       
                        <img class="car-img-top" src="/images/nokti.png" class="usluga_slika" style="width: 200px">
                        <span class="card-title text-center flavor_text"  >  <?php   echo anchor("$controller/sredjivanje_noktiju", " Sređivanje noktiju",'class="button4"'); ?></span>
                          
                       </div> 
                    
                    
                    
                    
                    
                    
                    </div>
                    <div class="col-sm-1" style="margin-left:-20px">
                 
                         <div  style="background-color: #FFC7C7; border-radius: 10px; width:300px ;min-height: 100px;
                                                            text-align: left;
                                                                margin: 50px;
                                                                 margin-bottom: 110px;  width:405px; margin-top:359px ">
                       
                           <img class="car-img-top" src="/images/oci.png" class="usluga_slika" style="width: 200px">
                            <span class="card-title text-center flavor_text"  >  <?php   echo anchor("$controller/ciscenje_ociju", "Čišćenje očiju",'class="button4"'); ?></span>
                          
                            </div> 
                      
                       </div> 
             
                     </div> 
                    
                  </div>
                </div>
                

             

            <div class="col-sm-1 " >

            </div>
            

        </div>
