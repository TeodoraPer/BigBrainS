<?php

?>
   <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
              <div class="sredina">
                  <h2 class="dobrodosliTekst alert alert-success" style='margin-right: 300px; margin-left: 300px'> <br><br>
                      Uspešno ste zakazali tretman! <br><br>
                  </h2>
                  <br>
                <hr class="linija">
              </div>
            </div>
            <div class="col-sm-1 " >
             
            </div>
         
        </div>

