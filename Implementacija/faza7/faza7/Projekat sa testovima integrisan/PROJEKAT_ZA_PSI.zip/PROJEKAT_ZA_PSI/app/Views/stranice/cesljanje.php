<?php
?>
   <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" > <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst"> ČEŠLJANJE </h2>
                
                <img class="usluga_slika2" src="/images/cesljanje.png">
                <p class="flavor_text" style="text-align: left;">Da li znate da četkanje pasa može pomoći da dlaka vašeg psa ostane čista i bez čvorova? Svaki vlasnik mora da brine o svom ljubimcu na pravi način.
                <br>
                <br>
                Bilo da je u pitanju veliki ili mali pas, mužjak ili ženka, štene ili odrastao pas četkanje je neophodno.
                <br>
                <br>
                Kao odgovoran vlasnik kućnih ljubimaca morate da znate da je dlaka odgledalo zdravlja kod pasa i zbog toga četkanje psa treba da postane deo vaše svakodnevne rutine.
                <br>
                <br>
                Pseće krzno sadrži prirodna ulja, ali pošto psi za razliku od mačaka ne mogu da održavaju svoju dlaku potrebna im je vaša pomoć u širenju tih prirodnih ulja. Četkanje će im pomoći da izgledaju sjajno i sprečiće nakupljanje masnih naslaga na dlaci i koži.
                <br>
                <br>
                <br>
                Na našoj platformi možete pronaći salone koji će se pobrinuti da vaš pas bude očešljan pravilno i dosledno, da bi bio lep i zbrinut u svakom pogledu!
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
        
        </div>
