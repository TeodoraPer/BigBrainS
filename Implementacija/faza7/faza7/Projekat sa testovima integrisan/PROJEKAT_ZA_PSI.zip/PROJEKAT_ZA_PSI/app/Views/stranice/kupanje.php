<?php
?>
  <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
                 <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst">KUPANJE </h2>
                <img class="usluga_slika2" src="/images/kupanje.png">
                <p class="flavor_text" style="text-align: left;">
                Kupanje pasa je sastavni deo brige o kućnim ljubimcima. Oni su deo našeg života, pružaju nam ljubav svakoga dana, a najmanje što možemo da učinimo za njih jeste da ih redovno hranimo i negujemo.
                <br><br>
                Iako psi vole vodu, kupanje im nije baš omiljena aktivnost. Međutim, ako na vreme počnete da navikavate ljubimca na šampon i pravilnu negu, ovaj postupak može da bude prava zabava. Prvo kupanje psa bi trebalo da bude u ranom uzrastu. Štenci se lakše dresiraju i prilagođavaju zahtevima vlasnika, pa ćete kasnije imati manje problema da psa „naterate” da bude miran tokom kupanja.
                <br><br>
                Čišćenje i nega kućnih ljubimaca bi trebalo da se održava redovno, bez obzira na to da li oni sve vreme borave u zatvorenom prostoru ili u dvorištu. Ipak, kupanje pasa ne sme da bude isuviše učestalo, posebno u zimskom periodu. Prečestim kupanjem se isušuje koža i ispiraju prirodne masnoće sa dlake, koje su životinjama potrebne, kako bi ih zaštitile od prevelike hladnoće i vlage.
                Ne postoji univerzalan odgovor na pitanje kako naći pravu meru. Koliko često bi trebalo da kupate kućnog ljubimca zavisi od mnogih faktora, a rasa je jedan od presudnih.
                <br><br>
                Kratkodlake pse bi trebalo kupati najmanje jednom do dva puta godišnje. Ukoliko pas najčešće boravi u zatvorenom prostoru, možete slobodno da se pridržavate ovog pravila. Psima koji provode vreme napolju, igraju se u prašini i blatu verovatno će biti potrebno češće kupanje. Rezervišite kupku za Vašeg ljubimca danas!
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
           
        </div>
