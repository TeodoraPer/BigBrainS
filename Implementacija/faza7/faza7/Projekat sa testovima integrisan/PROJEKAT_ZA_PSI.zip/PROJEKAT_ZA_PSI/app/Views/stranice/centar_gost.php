<?php
// Teodora Peric 0283/18 postavljanje pocetnu stranicu gosta koji je dizajnirao Pavle Stefanovic 0562/18
?>

        <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
              <div class="sredina">
                <h2 class="dobrodosliTekst">Dobrodošli u GroomRoom!</h2>
                <p class="flavor_text"> Naš cilj je da Vam omogućimo efikasan način za sređivanje Vašeg kućnog ljubimca!
                  <br>
                  Zakažite termin u salonu po vašem izboru danas!
      
                  <hr class="linija">
      
                <h2 class="dobrodosliTekst">Naši saloni</h2>
                <p class="flavor_text">Šta god da Vašem psu treba, naši saloni obezbeđuju!
                  <br>
                  Imamo najveći izbor salona, sa najkvalitetnijom uslugom!
                </p>
                </p>
                <hr class="linija">
              </div>
            </div>
            <div class="col-sm-1 " >
             
            </div>
         
        </div>