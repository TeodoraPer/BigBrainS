<?php
?>

        <div class="row divCentar">
            <div class="col-sm-1 " >

            </div>
            <div class="col-sm-10 centar" >
                 <br>
                 <?php   echo anchor("$controller/pregled_usluga", "Idi nazad",'class="button4"'); ?>
              <div class="sredina">
                <h2 class="uslugeTekst"> ČIŠĆENJE UŠIJU </h2>
                <img class="usluga_slika2" src="/images/usi.png">
                <p class="flavor_text" style="text-align: left;">
                  Čišćenje ušiju kod pasa mora biti sastavni deo nege vašeg ljubimca. Ukoliko do sada niste brinuli o ušima vašeg psa, evo kako to da učinite.
                  <br><br>
                  Svi vlasnici pasa znaju da je njihovim ljubimcima potrebna redovna nega i briga kako bi oni bili zdravi i srećni.
                  Pored redovnog kupanja pasa, svakom psu je potrebno s vremena na vreme očistiti uši da ne bi došlo do infekcije uha.
                  <br><br>
                  Ušni vosak koji se nakuplja u uhu, a ne uklanja se redovno, lako može da uđe dublje u ušni kanal. Tamo se sve više taloži i nakon određenog vremena može izazvati infekciju ušnog kanala.
                  <br><br>
                  Neke rase pasa za stan (npr. koker španijel, baset) u ušima imaju veliki broj žlezda koje luče prekomerne količine ušnog voska.
                  <br><br>
                  Nikada nije na odmet pomoći vašem psu. Na našoj platformi možete pronaći salone koji će se pobrinuti da uši Vašeg ljubimca budu čiste i zdrave!
                </p>
              </div>

            </div>
            <div class="col-sm-1 " >

            </div>
           
        </div>
